package edu.covenant.kepler.match3;

import android.content.Context;
import android.view.MotionEvent;
import coreAssets.CollisionException;
import coreAssets.ContinuousActionBoard;
import coreAssets.EndWall;
import coreAssets.GameOverException;
import coreAssets.Paddle;
import coreAssets.Point;
import coreAssets.Puck;
import coreAssets.PuckSupply;
import coreAssets.Rectangle;
import coreAssets.SideWall;
import coreAssets.SimpleScore;
import coreAssets.Size;

public class Match3Board extends ContinuousActionBoard {
	
	private TilePile tilePile;
	private boolean ptrReleased=true;
	private int tileColor;
	private int color1;
	private int color2;
	
	private int[] tile1={0,0};
	private int[] tile2={0,0};
	private static int[] colors={255 << 24 | 0 << 16 | 0 << 8 | 255,
		50 << 24 | 255 << 16 | 50 << 8 | 255,
		50 << 24 | 50 << 16 | 255 << 8 | 255,//light clear blue
		255 << 24 | 255 << 16 | 50 << 8 | 255,
		255 << 24 | 50 << 16 | 255 << 8 | 255,
		50 << 24 | 255 << 16 | 255 << 8 | 255};
	public Match3Board(int width, int height) {
		super(width, height);
		
		//buildGameBoard();
		this.name = "Match3";
		userInterupt = false;
	}
	
	public Match3Board() {
		super();
		//buildGameBoard();
		this.name = "Match3";
		userInterupt = false;
	}
	public Match3Board(int tileColor){
		super();
		this.tileColor=tileColor;
	}
	public void buildGameBoard() {
		tilePile = new TilePile(new Rectangle(new Point(0, 0), new Size(getWidth(), getHeight() - (getHeight() / 10))));
		addStationaryPiece(tilePile);	
	}

	public String getSaveData() {
		/*return pucksupply.getSaveData() + ":" + puck.getSaveData() + ":"
				+ paddle.getSaveData() + ":" + brickpile.getSaveData() + ":"
				+ score;*/
		return (tilePile.getSaveData()+":"+score);
		
	}

	public void setSaveData(String data) {
		/*pucksupply.setSaveData(data);
		data = data.substring(data.indexOf(":") + 1);
		puck.setSaveData(data);
		data = data.substring(data.indexOf(":") + 1);
		paddle.setSaveData(data);
		data = data.substring(data.indexOf(":") + 1);
//		brickpile.setSaveData(data.substring(0, data.indexOf(":")));
		gameOver = false;
		data = data.substring(data.indexOf(":") + 1);
		score = new SimpleScore(Integer.parseInt(data));*/
		
		gameOver = false;
		tilePile.setSaveData(data);
		data = data.substring(data.indexOf(":") + 1);
		score = new SimpleScore(Integer.parseInt(data));
	}

	protected void handleGameOverException(boolean won) {
		if (won) {
			score.incScore(1);
		}
		
	}

	protected void handleSpriteDeletedException() throws GameOverException {
		/*try {
			movableComponents.removeElement(puck);
			puck = pucksupply.getPuck(new Point((getWidth() / 2),
					(getHeight() / 2)));
			movableComponents.addElement(puck);
		} catch (GameOverException oope) {
			stopMovement();
			gameOver = true;
			throw new GameOverException(false, "You lost, score: " + score);
		}*/
	}

	protected void handleCollisionException(CollisionException ce) {
		if (ce.getSprite1().name.equals("Puck")
				&& ce.getSprite2().name.equals("Brick"))
			score.incScore(1);
	}

	public void ptrPressed(int x, int y) {
		 if (ptrReleased==true){
			 tile1[1]=(int) (x)/(getWidth()/8);
		        tile1[0]= (int) (y)/(getWidth()/8);
		        if (tile1[0]<8&&tile1[0]>=0&&tile1[1]<8&&tile1[1]>=0){
		        	color1=tilePile.pile[tile1[0]][tile1[1]].getColor();
		        	ptrReleased=false;
		        }
         	
         	}
         }
	
	
	public void ptrReleased(int x, int y){
		ptrReleased=true;
        tile2[1]=(x/(getWidth()/8));
        tile2[0]= (y/(getWidth()/8));
        if (tile2[0]<8&&tile2[0]>=0&&tile2[1]<8&&tile2[1]>=0){
        	color2=tilePile.pile[tile2[0]][tile2[1]].getColor();

        }
        
       if (((tile1[0]==tile2[0]-1||tile1[0]==tile2[0]+1)&&tile1[1]==tile2[1])
    		   ||((tile1[1]==tile2[1]-1||tile1[1]==tile2[1]+1))&&tile1[0]==tile2[0]){
       tilePile.pile[tile2[0]][tile2[1]].setColor(color1);
        tilePile.pile[tile1[0]][tile1[1]].setColor(color2);
     
        for(x = 0; x < tilePile.pile.length; x++){
			for(y = 0; y < tilePile.pile[0].length-2; y++){
				if((tilePile.pile[x][y].num != -1) && (tilePile.pile[x][y].num == tilePile.pile[x][y+1].num)){
					if(tilePile.pile[x][y] == tilePile.pile[x][y+2]){
						
						int length = 3;
						boolean plus = true;
						int o = 2;
						while(plus==true){
//							System.out.println(o);
							if(((y+o) < tilePile.pile[0].length-1) && (tilePile.pile[x][y].num == tilePile.pile[x][y+o].num)){
//								System.out.println("fall in");
								length = length + 1;
								o++;
//								System.out.println("Length: "+length+" o: "+o);
							}
							else{
								plus = false;
//								System.out.println("2 - Length: "+length+" o: "+o);
							}
						}
						
						for(int i = 0; i < length-1; i++){
							tilePile.pile[x][y+i].num = -1;
						}
						
//						fillBoard();
					}	
				}
				else{
					//System.out.println("check k: "+k);
				}
			}
    	}
			
    	//Vertical = a[0][0] == a[1][0]
    	for(y = 0; y < tilePile.pile.length; y++){
			for(x = 0; x < tilePile.pile[0].length-2; x++){
				if((tilePile.pile[x][y].num != -1) && (tilePile.pile[x][y].num == tilePile.pile[x+1][y].num)){
					if(tilePile.pile[x][y].num == tilePile.pile[x+2][y].num){
						
						int length = 3;
						boolean plus = true;
						int o = 2;
						while(plus==true){
							if(((x+o) < tilePile.pile.length-1) && (tilePile.pile[x][y].num == tilePile.pile[x+o][y].num)){
								length = length + 1;
								o++;
							}
							else{
								plus = false;
							}
						}
//						System.out.println("len "+length);
						for(int i = length-2; i >= 0; i--){
							tilePile.pile[x+i][y].num = -1;
						}
						
			//			fillBoard();
					}	
				}
				else{
					//System.out.println("check k: "+k);
				}
			}
		}
    	
        
        
    	
    }
    }

	public void ptrDragged(int x, int y) {
	}


	public void keyUp(boolean down) {
		userInterupt = true;
	}

	@Override
	public void loadGame(Context context) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void saveGame(Context context) {
		// TODO Auto-generated method stub
		
	}

}